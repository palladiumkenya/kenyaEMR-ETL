CREATE PROCEDURE sp_create_drug_order_events_tmp_table()
  BEGIN
DROP TABLE IF EXISTS kenyaemr_etl.tmp_regimen_events_ordered;

CREATE TABLE kenyaemr_etl.tmp_regimen_events_ordered AS
SELECT
uuid,
patient_id,
date_started,
originalRegimen,
DiscontinuedRegimen,
startedRegimen,
resultingRegimen,
@x:=IF(@same_value=patient_id,@x+1,1) as rowNum,
@same_value:=patient_id as dummy
FROM
(
SELECT
ThisRow.uuid,
ThisRow.patient_id,
ThisRow.date_started,
PrevRow.regimen originalRegimen,
REPLACE(PrevRow.regimen_discontinued, ",","|") DiscontinuedRegimen,
ThisRow.regimen startedRegimen,
concat_ws(",", PrevRow.regimen, ThisRow.regimen) as resultingRegimen
FROM
kenyaemr_etl.etl_drug_event    AS ThisRow
LEFT JOIN
kenyaemr_etl.etl_drug_event    AS PrevRow
ON  PrevRow.patient_id   = ThisRow.patient_id
AND PrevRow.date_started = (SELECT MAX(date_started)
FROM kenyaemr_etl.etl_drug_event
WHERE patient_id  = ThisRow.patient_id
AND date_started < ThisRow.date_started) order by patient_id, date_started
) u,
(SELECT  @x:=0, @same_value:='') t
ORDER BY patient_id, date_started;

END;
