CREATE PROCEDURE sp_update_etl_laboratory_extract(IN last_update_time DATETIME)
  BEGIN



    insert into kenyaemr_etl.etl_laboratory_extract(
      uuid,
      encounter_id,
      patient_id,
      location_id,
      visit_date,
      visit_id,
      lab_test,
      test_result,
      date_created,
      created_by
    )
      select
        o.uuid,
        e.encounter_id,
        e.patient_id,
        e.location_id,
        e.encounter_datetime as visit_date,
        e.visit_id,
        o.concept_id,
        (CASE when o.concept_id in(5497,730,654,790,856,21) then o.value_numeric
         when o.concept_id in(299,1030,302,32, 1305) then o.value_coded
         END) AS test_result,
        e.date_created,
        e.creator
      from encounter e
        inner join obs o on e.encounter_id=o.encounter_id and o.voided=0
                            and o.concept_id in (5497,730,299,654,790,856,1030,21,302,32, 1305)
        inner join
        (
          select encounter_type_id, uuid, name from encounter_type where uuid in('17a381d1-7e29-406a-b782-aa903b963c28', 'a0034eee-1940-4e35-847f-97537a35d05e')
        ) et on et.encounter_type_id=e.encounter_type
      where e.date_created >= last_update_time
            or e.date_changed >= last_update_time
            or e.date_voided >= last_update_time
            or o.date_created >= last_update_time
            or o.date_voided >= last_update_time
    ON DUPLICATE KEY UPDATE visit_date=VALUES(visit_date), lab_test=VALUES(lab_test), test_result=VALUES(test_result)
    ;

  END;
