CREATE PROCEDURE sp_update_drug_event_regimen_details()
  BEGIN
UPDATE kenyaemr_etl.etl_drug_event do
inner join kenyaemr_etl.tmp_regimen_events_ordered tmp on tmp.uuid=do.uuid and tmp.patient_id=do.patient_id
set do.regimen = tmp.resultingRegimen, do.regimen_name = (CASE
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "ABC+3TC+LPV/r"
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DIDANOSINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "ABC+ddI+LPV/r"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DARUNAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "AZT+3TC+DRV/r"
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DARUNAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "ABC+3TC+DRV/r"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "AZT+3TC+LPV/r"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ATAZANAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "AZT+3TC+ATV/r"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "TDF+3TC+LPV/r"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "TDF+ABC+LPV/r"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ATAZANAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "TDF+3TC+ATV/r"
WHEN FIND_IN_SET("STAVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "d4T+3TC+LPV/r"
WHEN FIND_IN_SET("STAVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "d4T+ABC+LPV/r"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DIDANOSINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "AZT+ddI+LPV/r"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "TDF+AZT+LPV/r"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "AZT+ABC+LPV/r"

WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("NEVIRAPINE", tmp.resultingRegimen) > 0  THEN "AZT+3TC+NVP"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("EFAVIRENZ", tmp.resultingRegimen) > 0  THEN "AZT+3TC+EFV"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0  THEN "AZT+3TC+ABC"

WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("NEVIRAPINE", tmp.resultingRegimen) > 0  THEN "TDF+3TC+NVP"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("EFAVIRENZ", tmp.resultingRegimen) > 0  THEN "TDF+3TC+EFV"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0  THEN "TDF+3TC+ABC"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0  THEN "TDF+3TC+AZT"

WHEN FIND_IN_SET("STAVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("NEVIRAPINE", tmp.resultingRegimen) > 0  THEN "d4T+3TC+NVP"
WHEN FIND_IN_SET("STAVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("EFAVIRENZ", tmp.resultingRegimen) > 0  THEN "d4T+3TC+EFV"
WHEN FIND_IN_SET("STAVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0  THEN "d4T+3TC+ABC"

WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("NEVIRAPINE", tmp.resultingRegimen) > 0  THEN "ABC+3TC+NVP"
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("EFAVIRENZ", tmp.resultingRegimen) > 0  THEN "ABC+3TC+EFV"
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0  THEN "ABC+3TC+AZT"

WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DOLUTEGRAVIR", tmp.resultingRegimen) > 0  THEN "AZT+3TC+DTG"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DOLUTEGRAVIR", tmp.resultingRegimen) > 0  THEN "TDF+3TC+DTG"
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DOLUTEGRAVIR", tmp.resultingRegimen) > 0  THEN "ABC+3TC+DTG"

WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ATAZANAVIR", tmp.resultingRegimen) > 0  THEN "TDF+3TC+ATV/r"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ATAZANAVIR", tmp.resultingRegimen) > 0  THEN "AZT+3TC+ATV/r"

END),
regimen_line = (CASE
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DIDANOSINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DARUNAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DARUNAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ATAZANAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ATAZANAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("STAVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("STAVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DIDANOSINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LOPINAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("RITONAVIR", tmp.resultingRegimen) > 0 THEN "2nd Line"

WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("NEVIRAPINE", tmp.resultingRegimen) > 0  THEN "1st Line"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("EFAVIRENZ", tmp.resultingRegimen) > 0  THEN "1st Line"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0  THEN "2nd Line"

WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("NEVIRAPINE", tmp.resultingRegimen) > 0  THEN "1st Line"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("EFAVIRENZ", tmp.resultingRegimen) > 0  THEN "1st Line"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0  THEN "2nd Line"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0  THEN "2nd Line"

WHEN FIND_IN_SET("STAVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("NEVIRAPINE", tmp.resultingRegimen) > 0  THEN "1st Line"
WHEN FIND_IN_SET("STAVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("EFAVIRENZ", tmp.resultingRegimen) > 0  THEN "1st Line"
WHEN FIND_IN_SET("STAVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0  THEN "2nd Line"

WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("NEVIRAPINE", tmp.resultingRegimen) > 0  THEN "1st Line"
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("EFAVIRENZ", tmp.resultingRegimen) > 0  THEN "1st Line"
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0  THEN "1st Line"

WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DOLUTEGRAVIR", tmp.resultingRegimen) > 0  THEN "1st Line"
WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DOLUTEGRAVIR", tmp.resultingRegimen) > 0  THEN "1st Line"
WHEN FIND_IN_SET("ABACAVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("DOLUTEGRAVIR", tmp.resultingRegimen) > 0  THEN "1st Line"

WHEN FIND_IN_SET("TENOFOVIR", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ATAZANAVIR", tmp.resultingRegimen) > 0  THEN "2nd Line"
WHEN FIND_IN_SET("ZIDOVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("LAMIVUDINE", tmp.resultingRegimen) > 0 AND FIND_IN_SET("ATAZANAVIR", tmp.resultingRegimen) > 0  THEN "2nd Line"

END);

END;
