CREATE PROCEDURE sp_update_etl_mch_enrollment(IN last_update_time DATETIME)
  BEGIN



    insert into kenyaemr_etl.etl_mch_enrollment(
      patient_id,
      uuid,
      visit_id,
      visit_date,
      location_id,
      encounter_id,
      anc_number,
      first_anc_visit_date,
      gravida,
      parity,
      parity_abortion,
      age_at_menarche,
      lmp,
      lmp_estimated,
      edd_ultrasound,
      blood_group,
      serology,
      tb_screening,
      bs_for_mps,
      hiv_status,
      hiv_test_date,
      partner_hiv_status,
      partner_hiv_test_date,
      urine_microscopy,
      urinary_albumin,
      glucose_measurement,
      urine_ph,
      urine_gravity,
      urine_nitrite_test,
      urine_leukocyte_esterace_test,
      urinary_ketone,
      urine_bile_salt_test,
      urine_bile_pigment_test,
      urine_colour,
      urine_turbidity,
      urine_dipstick_for_blood,
      -- date_of_discontinuation,
      discontinuation_reason
    )
      select
        e.patient_id,
        e.uuid,
        e.visit_id,
        e.encounter_datetime,
        e.location_id,
        e.encounter_id,
        max(if(o.concept_id=161655,o.value_numeric,null)) as anc_number,
        max(if(o.concept_id=163547,o.value_datetime,null)) as first_anc_visit_date,
        max(if(o.concept_id=5624,o.value_numeric,null)) as gravida,
        max(if(o.concept_id=160080,o.value_numeric,null)) as parity,
        max(if(o.concept_id=1823,o.value_numeric,null)) as parity_abortion,
        max(if(o.concept_id=160598,o.value_numeric,null)) as age_at_menarche,
        max(if(o.concept_id=1427,o.value_datetime,null)) as lmp,
        max(if(o.concept_id=162095,o.value_datetime,null)) as lmp_estimated,
        max(if(o.concept_id=5596,o.value_datetime,null)) as edd_ultrasound,
        max(if(o.concept_id=300,o.value_coded,null)) as blood_group,
        max(if(o.concept_id=299,o.value_coded,null)) as serology,
        max(if(o.concept_id=160108,o.value_coded,null)) as tb_screening,
        max(if(o.concept_id=32,o.value_coded,null)) as bs_for_mps,
        max(if(o.concept_id=159427,o.value_coded,null)) as hiv_status,
        max(if(o.concept_id=160554,o.value_datetime,null)) as hiv_test_date,
        max(if(o.concept_id=1436,o.value_coded,null)) as partner_hiv_status,
        max(if(o.concept_id=160082,o.value_datetime,null)) as partner_hiv_test_date,
        max(if(o.concept_id=56,o.value_text,null)) as urine_microscopy,
        max(if(o.concept_id=1875,o.value_coded,null)) as urinary_albumin,
        max(if(o.concept_id=159734,o.value_coded,null)) as glucose_measurement,
        max(if(o.concept_id=161438,o.value_numeric,null)) as urine_ph,
        max(if(o.concept_id=161439,o.value_numeric,null)) as urine_gravity,
        max(if(o.concept_id=161440,o.value_coded,null)) as urine_nitrite_test,
        max(if(o.concept_id=161441,o.value_coded,null)) as urine_leukocyte_esterace_test,
        max(if(o.concept_id=161442,o.value_coded,null)) as urinary_ketone,
        max(if(o.concept_id=161444,o.value_coded,null)) as urine_bile_salt_test,
        max(if(o.concept_id=161443,o.value_coded,null)) as urine_bile_pigment_test,
        max(if(o.concept_id=162106,o.value_coded,null)) as urine_colour,
        max(if(o.concept_id=162101,o.value_coded,null)) as urine_turbidity,
        max(if(o.concept_id=162096,o.value_coded,null)) as urine_dipstick_for_blood,
        -- max(if(o.concept_id=161655,o.value_text,null)) as date_of_discontinuation,
        max(if(o.concept_id=161555,o.value_coded,null)) as discontinuation_reason
      from encounter e
        inner join obs o on e.encounter_id = o.encounter_id and o.voided =0
                            and o.concept_id in(161655,163547,5624,160080,1823,160598,1427,162095,5596,300,299,160108,32,159427,160554,1436,160082,56,1875,159734,161438,161439,161440,161441,161442,161444,161443,162106,162101,162096,161555)
        inner join
        (
          select encounter_type_id, uuid, name from encounter_type where
            uuid in('3ee036d8-7c13-4393-b5d6-036f2fe45126')
        ) et on et.encounter_type_id=e.encounter_type
      where e.date_created >= last_update_time
            or e.date_changed >= last_update_time
            or e.date_voided >= last_update_time
            or o.date_created >= last_update_time
            or o.date_voided >= last_update_time
      group by e.encounter_id
    ON DUPLICATE KEY UPDATE visit_date=VALUES(visit_date),anc_number=VALUES(anc_number),first_anc_visit_date=VALUES(first_anc_visit_date),gravida=VALUES(gravida),parity=VALUES(parity),parity_abortion=VALUES(parity_abortion),age_at_menarche=VALUES(age_at_menarche),lmp=VALUES(lmp),lmp_estimated=VALUES(lmp_estimated),
      edd_ultrasound=VALUES(edd_ultrasound),blood_group=VALUES(blood_group),serology=VALUES(serology),tb_screening=VALUES(tb_screening),bs_for_mps=VALUES(bs_for_mps),hiv_status=VALUES(hiv_status),hiv_test_date=VALUES(hiv_status),partner_hiv_status=VALUES(partner_hiv_status),partner_hiv_test_date=VALUES(partner_hiv_test_date),
      urine_microscopy=VALUES(urine_microscopy),urinary_albumin=VALUES(urinary_albumin),glucose_measurement=VALUES(glucose_measurement),urine_ph=VALUES(urine_ph),urine_gravity=VALUES(urine_gravity),urine_nitrite_test=VALUES(urine_nitrite_test),urine_leukocyte_esterace_test=VALUES(urine_leukocyte_esterace_test),urinary_ketone=VALUES(urinary_ketone),
      urine_bile_salt_test=VALUES(urine_bile_salt_test),urine_bile_pigment_test=VALUES(urine_bile_pigment_test),urine_colour=VALUES(urine_colour),urine_turbidity=VALUES(urine_turbidity),urine_dipstick_for_blood=VALUES(urine_dipstick_for_blood),discontinuation_reason=VALUES(discontinuation_reason)
    ;

  END;
