CREATE PROCEDURE sp_populate_hts_linkage_and_referral()
  BEGIN
    SELECT "Processing hts linkages, referrals and tracing";
    INSERT INTO kenyaemr_etl.etl_hts_referral_and_linkage (
      patient_id,
      visit_id,
      encounter_id,
      encounter_uuid,
      encounter_location,
      creator,
      date_created,
      visit_date,
      tracing_type,
      tracing_status,
      facility_linked_to,
      ccc_number,
      provider_handed_to,
      voided
    )
      select
        e.patient_id,
        e.visit_id,
        e.encounter_id,
        e.uuid,
        e.location_id,
        e.creator,
        e.date_created,
        e.encounter_datetime as visit_date,
        max(if(o.concept_id=164966,(case o.value_coded when 1650 then "Phone" when 164965 then "Physical" else "" end),null)) as tracing_type ,
        max(if(o.concept_id=159811,(case o.value_coded when 1065 then "Contacted and linked" when 1066 then "Contacted but not linked" else "" end),null)) as tracing_status,
        max(if(o.concept_id=162724,o.value_text,null)) as facility_linked_to,
        max(if(o.concept_id=162053,o.value_numeric,null)) as ccc_number,
        max(if(o.concept_id=1473,o.value_text,null)) as provider_handed_to,
        e.voided
      from encounter e
        inner join form f on f.form_id = e.form_id and f.uuid = "050a7f12-5c52-4cad-8834-863695af335d"
        left outer join obs o on o.encounter_id = e.encounter_id and o.concept_id in (164966, 159811, 162724, 162053, 1473)
      group by e.encounter_id;

    -- fetch locally enrolled clients who had went through HTS

    INSERT INTO kenyaemr_etl.etl_hts_referral_and_linkage (
      patient_id,
      visit_id,
      encounter_id,
      encounter_uuid,
      encounter_location,
      creator,
      date_created,
      visit_date,
      tracing_status,
      facility_linked_to,
      ccc_number,
      voided
    )
      select
        e.patient_id,
        e.visit_id,
        e.encounter_id,
        e.uuid,
        e.location_id,
        e.creator,
        e.date_created,
        e.encounter_datetime as visit_date,
        "Enrolled" as contact_status,
        (select name from location
        where location_id in (select property_value
                              from global_property
                              where property='kenyaemr.defaultLocation'))  as facility_linked_to,
        pi.identifier as ccc_number,
        e.voided
      from encounter e
        inner join encounter_type et on e.encounter_type = et.encounter_type_id and et.uuid = "de78a6be-bfc5-4634-adc3-5f1a280455cc"
        inner join form f on f.form_id = e.form_id and f.uuid in ("402dc5d7-46da-42d4-b2be-f43ea4ad87b0","b08471f6-0892-4bf7-ab2b-bf79797b8ea4")
        left outer join patient_identifier pi on pi.patient_id = e.patient_id
        left join patient_identifier_type pit on pi.identifier_type=pit.patient_identifier_type_id and pit.uuid = '05ee9cf4-7242-4a17-b4d4-00f707265c8a'
    ;

  END;
