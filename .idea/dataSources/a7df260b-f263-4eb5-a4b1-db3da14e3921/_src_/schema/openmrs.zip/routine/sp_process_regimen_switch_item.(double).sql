CREATE PROCEDURE sp_process_regimen_switch_item(IN rowNum DOUBLE)
  BEGIN
DECLARE exec_status INT(11) DEFAULT 1;


DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
BEGIN
SET exec_status = -1;
ROLLBACK;
END;
START TRANSACTION;

UPDATE kenyaemr_etl.tmp_regimen_events_ordered t
inner join (
select ThisRow.rowNum ThisRowNum, ThisRow.uuid, ThisRow.patient_id,ThisRow.originalRegimen,  ThisRow.startedRegimen, ThisRow.DiscontinuedRegimen, PrevRow.resultingRegimen prevRowResultingRegimen
from kenyaemr_etl.tmp_regimen_events_ordered ThisRow inner join kenyaemr_etl.tmp_regimen_events_ordered PrevRow on ThisRow.patient_id=PrevRow.patient_id and ThisRow.rowNum=(PrevRow.rowNum+1)
where ThisRow.rowNum=rowNum order by ThisRow.patient_id, ThisRow.rowNum
) u on u.uuid = t.uuid
SET t.originalRegimen=u.prevRowResultingRegimen,
t.resultingRegimen=IF(CONVERT(REPLACE(TRIM(BOTH ',' FROM openmrs.process_regimen_switch(u.prevRowResultingRegimen, CONCAT("(", t.DiscontinuedRegimen, ")"), '', TRUE, 0, 0)),",,", "," ) USING utf8) is not null
AND u.startedRegimen <> '',
concat_ws(",", u.startedRegimen, CONVERT(REPLACE(TRIM(BOTH ',' FROM openmrs.process_regimen_switch(u.prevRowResultingRegimen, CONCAT("(", t.DiscontinuedRegimen, ")"), '', TRUE, 0, 0)),",,", "," ) USING utf8)),
u.prevRowResultingRegimen
);


COMMIT;

END;
