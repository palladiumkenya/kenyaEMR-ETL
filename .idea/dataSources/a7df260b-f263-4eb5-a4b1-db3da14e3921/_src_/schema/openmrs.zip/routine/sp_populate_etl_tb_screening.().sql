CREATE PROCEDURE sp_populate_etl_tb_screening()
  BEGIN
    SELECT "Processing TB Screening data ", CONCAT("Time: ", NOW());

    insert into kenyaemr_etl.etl_tb_screening(
      patient_id,
      uuid,
      provider,
      visit_id,
      visit_date,
      encounter_id,
      location_id,
      resulting_tb_status ,
      tb_treatment_start_date ,
      notes
    )
      select
        e.patient_id, e.uuid, e.creator, e.visit_id, e.encounter_datetime, e.encounter_id, e.location_id,
        max(case o.concept_id when 1659 then o.value_coded else "" end) as resulting_tb_status,
        max(case o.concept_id when 1113 then date(o.value_datetime)  else "" end) as tb_treatment_start_date,
        max(case o.concept_id when 160632 then value_text else "" end) as notes
      from encounter e
        inner join form f on f.form_id=e.form_id and f.uuid in ("22c68f86-bbf0-49ba-b2d1-23fa7ccf0259", "59ed8e62-7f1f-40ae-a2e3-eabe350277ce")
        inner join obs o on o.encounter_id = e.encounter_id and o.concept_id in (1659, 1113, 160632)
      where e.voided=0
      group by e.encounter_id;

    SELECT "Completed processing TB Screening data ", CONCAT("Time: ", NOW());
  END;
