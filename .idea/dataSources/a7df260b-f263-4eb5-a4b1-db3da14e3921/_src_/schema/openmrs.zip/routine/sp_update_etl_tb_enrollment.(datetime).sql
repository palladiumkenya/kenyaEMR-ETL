CREATE PROCEDURE sp_update_etl_tb_enrollment(IN last_update_time DATETIME)
  BEGIN



    insert into kenyaemr_etl.etl_tb_enrollment(
      patient_id,
      uuid,
      provider,
      visit_id,
      visit_date,
      location_id,
      encounter_id,
      date_treatment_started,
      district,
      -- district_registration_number,
      referred_by,
      referral_date,
      date_transferred_in,
      facility_transferred_from,
      district_transferred_from,
      date_first_enrolled_in_tb_care,
      weight,
      height,
      treatment_supporter,
      relation_to_patient,
      treatment_supporter_address,
      treatment_supporter_phone_contact,
      disease_classification,
      patient_classification,
      pulmonary_smear_result,
      has_extra_pulmonary_pleurial_effusion,
      has_extra_pulmonary_milliary,
      has_extra_pulmonary_lymph_node,
      has_extra_pulmonary_menengitis,
      has_extra_pulmonary_skeleton,
      has_extra_pulmonary_abdominal
      -- has_extra_pulmonary_other,
      -- treatment_outcome,
      -- treatment_outcome_date
    )
      select
        e.patient_id,
        e.uuid,
        e.creator,
        e.visit_id,
        e.encounter_datetime,
        e.location_id,
        e.encounter_id,
        max(if(o.concept_id=1113,o.value_datetime,null)) as date_treatment_started,
        max(if(o.concept_id=161564,o.value_text,null)) as district,
        -- max(if(o.concept_id=5085,o.value_numeric,null)) as district_registration_number,
        max(if(o.concept_id=160540,o.value_coded,null)) as referred_by,
        max(if(o.concept_id=161561,o.value_datetime,null)) as referral_date,
        max(if(o.concept_id=160534,o.value_datetime,null)) as date_transferred_in,
        max(if(o.concept_id=160535,o.value_text,null)) as facility_transferred_from,
        max(if(o.concept_id=161551,o.value_text,null)) as district_transferred_from,
        max(if(o.concept_id=161552,o.value_datetime,null)) as date_first_enrolled_in_tb_care,
        max(if(o.concept_id=5089,o.value_numeric,null)) as weight,
        max(if(o.concept_id=5090,o.value_numeric,null)) as height,
        max(if(o.concept_id=160638,o.value_text,null)) as treatment_supporter,
        max(if(o.concept_id=160640,o.value_coded,null)) as relation_to_patient,
        max(if(o.concept_id=160641,o.value_text,null)) as treatment_supporter_address,
        max(if(o.concept_id=160642,o.value_text,null)) as treatment_supporter_phone_contact,
        max(if(o.concept_id=160040,o.value_coded,null)) as disease_classification,
        max(if(o.concept_id=159871,o.value_coded,null)) as patient_classification,
        max(if(o.concept_id=159982,o.value_coded,null)) as pulmonary_smear_result,
        max(if(o.concept_id=161356 and o.value_coded=130059,o.value_coded,null)) as has_extra_pulmonary_pleurial_effusion,
        max(if(o.concept_id=161356 and o.value_coded=115753,o.value_coded,null)) as has_extra_pulmonary_milliary,
        max(if(o.concept_id=161356 and o.value_coded=111953,o.value_coded,null)) as has_extra_pulmonary_lymph_node,
        max(if(o.concept_id=161356 and o.value_coded=111967,o.value_coded,null)) as has_extra_pulmonary_menengitis,
        max(if(o.concept_id=161356 and o.value_coded=112116,o.value_coded,null)) as has_extra_pulmonary_skeleton,
        max(if(o.concept_id=161356 and o.value_coded=1350,o.value_coded,null)) as has_extra_pulmonary_abdominal
      -- max(if(o.concept_id=161356,o.value_coded,null)) as has_extra_pulmonary_other
      -- max(if(o.concept_id=159786,o.value_coded,null)) as treatment_outcome,
      -- max(if(o.concept_id=159787,o.value_coded,null)) as treatment_outcome_date

      from encounter e
        inner join obs o on e.encounter_id = o.encounter_id and o.voided =0
                            and o.concept_id in(160540,161561,160534,160535,161551,161552,5089,5090,160638,160640,160641,160642,160040,159871,159982,161356)
        inner join
        (
          select encounter_type_id, uuid, name from encounter_type where
            uuid in('9d8498a4-372d-4dc4-a809-513a2434621e')
        ) et on et.encounter_type_id=e.encounter_type
      where e.date_created >= last_update_time
            or e.date_changed >= last_update_time
            or e.date_voided >= last_update_time
            or o.date_created >= last_update_time
            or o.date_voided >= last_update_time
      group by e.encounter_id
    ON DUPLICATE KEY UPDATE provider=VALUES(provider),visit_id=VALUES(visit_id),visit_date=VALUES(visit_date),encounter_id=VALUES(encounter_id),date_treatment_started=VALUES(date_treatment_started),district=VALUES(district),referred_by=VALUES(referred_by),referral_date=VALUES(referral_date),
      date_transferred_in=VALUES(date_transferred_in),facility_transferred_from=VALUES(facility_transferred_from),district_transferred_from=VALUES(district_transferred_from),date_first_enrolled_in_tb_care=VALUES(date_first_enrolled_in_tb_care),weight=VALUES(weight),height=VALUES(height),treatment_supporter=VALUES(treatment_supporter),relation_to_patient=VALUES(relation_to_patient),
      treatment_supporter_address=VALUES(treatment_supporter_address),treatment_supporter_phone_contact=VALUES(treatment_supporter_phone_contact),disease_classification=VALUES(disease_classification),patient_classification=VALUES(patient_classification),pulmonary_smear_result=VALUES(pulmonary_smear_result),has_extra_pulmonary_pleurial_effusion=VALUES(has_extra_pulmonary_pleurial_effusion),
      has_extra_pulmonary_milliary=VALUES(has_extra_pulmonary_milliary),has_extra_pulmonary_lymph_node=VALUES(has_extra_pulmonary_lymph_node),has_extra_pulmonary_menengitis=VALUES(has_extra_pulmonary_menengitis),has_extra_pulmonary_skeleton=VALUES(has_extra_pulmonary_skeleton),has_extra_pulmonary_abdominal=VALUES(has_extra_pulmonary_abdominal)
    ;

  END;
