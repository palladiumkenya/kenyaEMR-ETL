CREATE PROCEDURE sp_populate_etl_laboratory_extract()
  BEGIN
    SELECT "Processing Laboratory data ", CONCAT("Time: ", NOW());
    insert into kenyaemr_etl.etl_laboratory_extract(
      uuid,
      encounter_id,
      patient_id,
      location_id,
      visit_date,
      visit_id,
      lab_test,
      test_result,
      -- date_test_requested,
      -- date_test_result_received,
      -- test_requested_by,
      date_created,
      created_by
    )
      select
        o.uuid,
        e.encounter_id,
        e.patient_id,
        e.location_id,
        e.encounter_datetime as visit_date,
        e.visit_id,
        o.concept_id,
        (CASE when o.concept_id in(5497,730,654,790,856,21) then o.value_numeric
         when o.concept_id in(299,1030,302,32, 1305) then o.value_coded
         END) AS test_result,
        -- date requested,
        -- date result received
        -- test requested by
        e.date_created,
        e.creator
      from encounter e
        inner join obs o on e.encounter_id=o.encounter_id and o.voided=0
                            and o.concept_id in (5497,730,299,654,790,856,1030,21,302,32, 1305) -- (5497-N,730-N,299-C,654-N,790-N,856-N,1030-C,21-N,302-C,32-C)
        inner join
        (
          select encounter_type_id, uuid, name from encounter_type where uuid in('17a381d1-7e29-406a-b782-aa903b963c28', 'a0034eee-1940-4e35-847f-97537a35d05e')
        ) et on et.encounter_type_id=e.encounter_type
    ;

    /*-- >>>>>>>>>>>>>>> -----------------------------------  Wagners input ------------------------------------------------------------
    insert into kenyaemr_etl.etl_laboratory_extract(
    encounter_id,
    patient_id,
    visit_date,
    visit_id,
    lab_test,
    test_result,
    -- date_test_requested,
    -- date_test_result_received,
    -- test_requested_by,
    date_created,
    created_by
    )
    select
    e.encounter_id,
    e.patient_id,
    e.encounter_datetime as visit_date,
    e.visit_id,
    o.concept_id,
    (CASE when o.concept_id in(5497,730,654,790,856,21) then o.value_numeric
    when o.concept_id in(299,1030,302,32) then o.value_coded
    END) AS test_result,
    -- date requested,
    -- date result received
    -- test requested by
    e.date_created,
    e.creator
    from encounter e, obs o, encounter_type et
    where e.encounter_id=o.encounter_id and o.voided=0
    and o.concept_id in (5497,730,299,654,790,856,1030,21,302,32) and et.encounter_type_id=e.encounter_type
    group by e.encounter_id;

    -- --------<<<<<<<<<<<<<<<<<<<< ------------------------------------------------------------------------------------------------------
    */
    SELECT "Completed processing Laboratory data ", CONCAT("Time: ", NOW());
  END;
