CREATE PROCEDURE sp_populate_etl_mch_discharge()
  BEGIN
    SELECT "Processing MCH Discharge ", CONCAT("Time: ", NOW());
    insert into kenyaemr_etl.etl_mchs_discharge(
      patient_id,
      uuid,
      provider,
      visit_id,
      visit_date,
      location_id,
      encounter_id,
      data_entry_date,
      counselled_on_feeding,
      baby_status,
      vitamin_A_dispensed,
      birth_notification_number,
      maternal_condition,
      discharge_date,
      referred_from,
      referred_to,
      clinical_notes
    )
      select
        e.patient_id,
        e.uuid,
        e.creator,
        e.visit_id,
        e.encounter_datetime,
        e.location_id,
        e.encounter_id,
        e.date_created,
        max(if(o.concept_id=161651,o.value_coded,null)) as counselled_on_feeding,
        max(if(o.concept_id=159926,o.value_coded,null)) as baby_status,
        max(if(o.concept_id=161534,o.value_coded,null)) as vitamin_A_dispensed,
        max(if(o.concept_id=162051,o.value_text,null)) as birth_notification_number,
        max(if(o.concept_id=162093,o.value_text,null)) as condition_of_mother,
        max(if(o.concept_id=1641,o.value_datetime,null)) as discharge_date,
        max(if(o.concept_id=160481,o.value_coded,null)) as referred_from,
        max(if(o.concept_id=163145,o.value_coded,null)) as referred_to,
        max(if(o.concept_id=159395,o.value_text,null)) as clinical_notes
      from encounter e
        inner join obs o on e.encounter_id = o.encounter_id and o.voided =0
                            and o.concept_id in(161651,159926,161534,162051,162093,1641,160481,163145,159395)
        inner join
        (
          select encounter_type, uuid,name from form where
            uuid in('af273344-a5f9-11e8-98d0-529269fb1459')
        ) f on f.encounter_type=e.encounter_type
      group by e.encounter_id ;
    SELECT "Completed processing MCH Discharge visits", CONCAT("Time: ", NOW());
  END;
