CREATE PROCEDURE sp_process_regimen_switch_list()
  BEGIN

DECLARE no_more_rows BOOLEAN;
DECLARE eRowNum double;
DECLARE v_row_count INT(11);

DECLARE existing_drug_orders CURSOR FOR
SELECT distinct rowNum FROM kenyaemr_etl.tmp_regimen_events_ordered order by rowNum;

DECLARE CONTINUE HANDLER FOR NOT FOUND
SET no_more_rows = TRUE;

OPEN existing_drug_orders;
SET v_row_count = FOUND_ROWS();

IF v_row_count > 0 THEN
getUniqueNumRows: LOOP
FETCH existing_drug_orders INTO eRowNum;

IF no_more_rows THEN
CLOSE existing_drug_orders;
LEAVE getUniqueNumRows;
END IF;

IF eRowNum > 1 THEN
CALL sp_process_regimen_switch_item(eRowNum);
END IF;


END LOOP getUniqueNumRows;
ELSE
SELECT "NO ROWS WERE FOUND";
END IF;

END;
