CREATE PROCEDURE sp_update_etl_mch_postnatal_visit(IN last_update_time DATETIME)
  BEGIN



    insert into kenyaemr_etl.etl_mch_postnatal_visit(
      patient_id,
      uuid,
      visit_id,
      visit_date,
      location_id,
      encounter_id,
      provider,
      pnc_register_no,
      pnc_visit_no,
      delivery_date,
      mode_of_delivery,
      place_of_delivery,
      temperature,
      pulse_rate,
      systolic_bp,
      diastolic_bp,
      respiratory_rate,
      oxygen_saturation,
      weight,
      height,
      muac,
      hemoglobin,
      arv_status,
      general_condition,
      breast,
      cs_scar,
      gravid_uterus,
      episiotomy,
      lochia,
      pallor,
      pph,
      mother_hiv_status,
      condition_of_baby,
      baby_feeding_method,
      umblical_cord,
      baby_immunization_started,
      family_planning_counseling,
      uterus_examination,
      uterus_cervix_examination,
      vaginal_examination,
      parametrial_examination,
      external_genitalia_examination,
      ovarian_examination,
      pelvic_lymph_node_exam,
      test_1_kit_name,
      test_1_kit_lot_no,
      test_1_kit_expiry,
      test_1_result,
      test_2_kit_name,
      test_2_kit_lot_no,
      test_2_kit_expiry,
      test_2_result,
      final_test_result,
      patient_given_result,
      partner_hiv_tested,
      partner_hiv_status,
      prophylaxis_given,
      haart_given_anc,
      haart_given_mat,
      haart_start_date,
      azt_dispensed,
      nvp_dispensed,
      maternal_condition_coded,
      iron_supplementation,
      fistula_screening,
      cacx_screening,
      cacx_screening_method,
      family_planning_status,
      family_planning_method,
      referred_from,
      referred_to,
      clinical_notes
    )
      select
        e.patient_id,
        e.uuid,
        e.visit_id,
        e.encounter_datetime,
        e.location_id,
        e.encounter_id,
        e.creator,
        max(if(o.concept_id=1646,o.value_text,null)) as pnc_register_no,
        max(if(o.concept_id=159893,o.value_numeric,null)) as pnc_visit_no,
        max(if(o.concept_id=5599,o.value_datetime,null)) as delivery_date,
        max(if(o.concept_id=5630,o.value_coded,null)) as mode_of_delivery,
        max(if(o.concept_id=1572,o.value_coded,null)) as place_of_delivery,
        max(if(o.concept_id=5088,o.value_numeric,null)) as temperature,
        max(if(o.concept_id=5087,o.value_numeric,null)) as pulse_rate,
        max(if(o.concept_id=5085,o.value_numeric,null)) as systolic_bp,
        max(if(o.concept_id=5086,o.value_numeric,null)) as diastolic_bp,
        max(if(o.concept_id=5242,o.value_numeric,null)) as respiratory_rate,
        max(if(o.concept_id=5092,o.value_numeric,null)) as oxygen_saturation,
        max(if(o.concept_id=5089,o.value_numeric,null)) as weight,
        max(if(o.concept_id=5090,o.value_numeric,null)) as height,
        max(if(o.concept_id=1343,o.value_numeric,null)) as muac,
        max(if(o.concept_id=21,o.value_numeric,null)) as hemoglobin,
        max(if(o.concept_id=1147,o.value_coded,null)) as arv_status,
        max(if(o.concept_id=160085,o.value_coded,null)) as general_condition,
        max(if(o.concept_id=159780,o.value_coded,null)) as breast,
        max(if(o.concept_id=162128,o.value_coded,null)) as cs_scar,
        max(if(o.concept_id=162110,o.value_coded,null)) as gravid_uterus,
        max(if(o.concept_id=159840,o.value_coded,null)) as episiotomy,
        max(if(o.concept_id=159844,o.value_coded,null)) as lochia,
        max(if(o.concept_id=5245,o.value_coded,null)) as pallor,
        max(if(o.concept_id=230,o.value_coded,null)) as pph,
        max(if(o.concept_id=1396,o.value_coded,null)) as mother_hiv_status,
        max(if(o.concept_id=162134,o.value_coded,null)) as condition_of_baby,
        max(if(o.concept_id=1151,o.value_coded,null)) as baby_feeding_method,
        max(if(o.concept_id=162121,o.value_coded,null)) as umblical_cord,
        max(if(o.concept_id=162127,o.value_coded,null)) as baby_immunization_started,
        max(if(o.concept_id=1382,o.value_coded,null)) as family_planning_counseling,
        max(if(o.concept_id=160967,o.value_text,null)) as uterus_examination,
        max(if(o.concept_id=160968,o.value_text,null)) as uterus_cervix_examination,
        max(if(o.concept_id=160969,o.value_text,null)) as vaginal_examination,
        max(if(o.concept_id=160970,o.value_text,null)) as parametrial_examination,
        max(if(o.concept_id=160971,o.value_text,null)) as external_genitalia_examination,
        max(if(o.concept_id=160975,o.value_text,null)) as ovarian_examination,
        max(if(o.concept_id=160972,o.value_text,null)) as pelvic_lymph_node_exam,
        max(if(t.test_1_result is not null, t.kit_name, "")) as test_1_kit_name,
        max(if(t.test_1_result is not null, t.lot_no, "")) as test_1_kit_lot_no,
        max(if(t.test_1_result is not null, t.expiry_date, "")) as test_1_kit_expiry,
        max(if(t.test_1_result is not null, t.test_1_result, "")) as test_1_result,
        max(if(t.test_2_result is not null, t.kit_name, "")) as test_2_kit_name,
        max(if(t.test_2_result is not null, t.lot_no, "")) as test_2_kit_lot_no,
        max(if(t.test_2_result is not null, t.expiry_date, "")) as test_2_kit_expiry,
        max(if(t.test_2_result is not null, t.test_2_result, "")) as test_2_result,
        max(if(o.concept_id=159427,(case o.value_coded when 703 then "Positive" when 664 then "Negative" when 1138 then "Inconclusive" else "" end),null)) as final_test_result,
        max(if(o.concept_id=164848,(case o.value_coded when 1065 then "Yes" when 1066 then "No" else "" end),null)) as patient_given_result,
        max(if(o.concept_id=161557,(case o.value_coded when 1065 then "Yes" when 1066 then "No" else "" end),null)) as partner_hiv_tested,
        max(if(o.concept_id=1436,(case o.value_coded when 703 then "Positive" when 664 then "Negative" when 1067 then "Unknown" else "" end),null)) as partner_hiv_status,
        max(if(o.concept_id=1109,o.value_coded,null)) as prophylaxis_given,
        max(if(o.concept_id=5576,o.value_coded,null)) as haart_given_anc,
        max(if(o.concept_id=159595,o.value_coded,null)) as haart_given_mat,
        max(if(o.concept_id=163784,o.value_datetime,null)) as haart_start_date,
        max(if(o.concept_id=1282,o.value_coded,null)) as azt_dispensed,
        max(if(o.concept_id=1282,o.value_coded,null)) as nvp_dispensed,
        max(if(o.concept_id=160085,o.value_coded,null)) as maternal_condition_coded,
        max(if(o.concept_id=161004,o.value_coded,null)) as iron_supplementation,
        max(if(o.concept_id=159921,o.value_coded,null)) as fistula_screening,
        max(if(o.concept_id=164934,o.value_coded,null)) as cacx_screening,
        max(if(o.concept_id=163589,o.value_coded,null)) as cacx_screening_method,
        max(if(o.concept_id=160653,o.value_coded,null)) as family_planning_status,
        max(if(o.concept_id=374,o.value_coded,null)) as family_planning_method,
        max(if(o.concept_id=160481,o.value_coded,null)) as referred_from,
        max(if(o.concept_id=163145,o.value_coded,null)) as referred_to,
        max(if(o.concept_id=159395,o.value_text,null)) as clinical_notes


      from encounter e
        inner join obs o on e.encounter_id = o.encounter_id and o.voided =0
                            and o.concept_id in(1646,159893,5599,5630,1572,5088,5087,5085,5086,5242,5092,5089,5090,1343,21,1147,160085,159780,162128,162110,159840,159844,5245,230,1396,162134,1151,162121,162127,1382,160967,160968,160969,160970,160971,160975,160972,159427,164848,161557,1436,1109,5576,159595,163784,1282,160085,161004,159921,164934,163589,160653,374,160481,163145,159395)
        inner join
        (
          select encounter_type, uuid,name from form where
            uuid in('72aa78e0-ee4b-47c3-9073-26f3b9ecc4a7')
        ) f on f.encounter_type=e.encounter_type
        inner join (
                     select
                       o.person_id,
                       o.encounter_id,
                       o.obs_group_id,
                       max(if(o.concept_id=1040, (case o.value_coded when 703 then "Positive" when 664 then "Negative" when 163611 then "Invalid"  else "" end),null)) as test_1_result ,
                       max(if(o.concept_id=1326, (case o.value_coded when 703 then "Positive" when 664 then "Negative" when 1175 then "N/A"  else "" end),null)) as test_2_result ,
                       max(if(o.concept_id=164962, (case o.value_coded when 164960 then "Determine" when 164961 then "First Response" else "" end),null)) as kit_name ,
                       max(if(o.concept_id=164964,o.value_text,null)) as lot_no,
                       max(if(o.concept_id=162502,date(o.value_datetime),null)) as expiry_date
                     from obs o
                       inner join encounter e on e.encounter_id = o.encounter_id
                       inner join form f on f.form_id=e.form_id and f.uuid in ('72aa78e0-ee4b-47c3-9073-26f3b9ecc4a7')
                     where o.concept_id in (1040, 1326, 164962, 164964, 162502)
                     group by e.encounter_id, o.obs_group_id
                   ) t on e.encounter_id = t.encounter_id
      where e.date_created >= last_update_time
            or e.date_changed >= last_update_time
            or e.date_voided >= last_update_time
            or o.date_created >= last_update_time
            or o.date_voided >= last_update_time

      group by e.encounter_id
    ON DUPLICATE KEY UPDATE visit_date=VALUES(visit_date),encounter_id=VALUES(encounter_id),provider=VALUES(provider),pnc_register_no=VALUES(pnc_register_no),pnc_visit_no=VALUES(pnc_visit_no),delivery_date=VALUES(delivery_date),mode_of_delivery=VALUES(mode_of_delivery),place_of_delivery=VALUES(place_of_delivery),temperature=VALUES(temperature),pulse_rate=VALUES(pulse_rate),systolic_bp=VALUES(systolic_bp),diastolic_bp=VALUES(diastolic_bp),respiratory_rate=VALUES(respiratory_rate),
      oxygen_saturation=VALUES(oxygen_saturation),weight=VALUES(weight),height=VALUES(height),muac=VALUES(muac),hemoglobin=VALUES(hemoglobin),arv_status=VALUES(arv_status),general_condition=VALUES(general_condition),breast=VALUES(breast),cs_scar=VALUES(cs_scar),gravid_uterus=VALUES(gravid_uterus),episiotomy=VALUES(episiotomy),
      lochia=VALUES(lochia),pallor=VALUES(pallor),pph=VALUES(pph),mother_hiv_status=VALUES(mother_hiv_status),condition_of_baby=VALUES(condition_of_baby),baby_feeding_method=VALUES(baby_feeding_method),umblical_cord=VALUES(umblical_cord),baby_immunization_started=VALUES(baby_immunization_started),family_planning_counseling=VALUES(family_planning_counseling),uterus_examination=VALUES(uterus_examination),
      uterus_cervix_examination=VALUES(uterus_cervix_examination),vaginal_examination=VALUES(vaginal_examination),parametrial_examination=VALUES(parametrial_examination),external_genitalia_examination=VALUES(external_genitalia_examination),ovarian_examination=VALUES(ovarian_examination),pelvic_lymph_node_exam=VALUES(pelvic_lymph_node_exam),
      test_1_kit_name=VALUES(test_1_kit_name),test_1_kit_lot_no=VALUES(test_1_kit_lot_no),test_1_kit_expiry=VALUES(test_1_kit_expiry),test_1_result=VALUES(test_1_result),test_2_kit_name=VALUES(test_2_kit_name),test_2_kit_lot_no=VALUES(test_2_kit_lot_no),test_2_kit_expiry=VALUES(test_2_kit_expiry),test_2_result=VALUES(test_2_result),final_test_result=VALUES(final_test_result),
      patient_given_result=VALUES(patient_given_result),partner_hiv_tested=VALUES(partner_hiv_tested),partner_hiv_status=VALUES(partner_hiv_status),prophylaxis_given=VALUES(prophylaxis_given),haart_given_anc=VALUES(haart_given_anc),haart_given_mat=VALUES(haart_given_mat),haart_start_date=VALUES(haart_start_date),azt_dispensed=VALUES(azt_dispensed),nvp_dispensed=VALUES(nvp_dispensed)
      ,maternal_condition_coded=VALUES(maternal_condition_coded),iron_supplementation=VALUES(iron_supplementation),fistula_screening=VALUES(fistula_screening),cacx_screening=VALUES(cacx_screening),cacx_screening_method=VALUES(cacx_screening_method),family_planning_status=VALUES(family_planning_status),family_planning_method=VALUES(family_planning_method)
      ,referred_from=VALUES(referred_from),referred_to=VALUES(referred_to), clinical_notes=VALUES(clinical_notes)
    ;

  END;
