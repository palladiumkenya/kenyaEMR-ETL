CREATE PROCEDURE sp_update_etl_mch_delivery(IN last_update_time DATETIME)
  BEGIN
    insert into kenyaemr_etl.etl_mchs_delivery(
      patient_id,
      uuid,
      provider,
      visit_id,
      visit_date,
      location_id,
      encounter_id,
      data_entry_date,
      duration_of_pregnancy,
      mode_of_delivery,
      date_of_delivery,
      blood_loss,
      condition_of_mother ,
      apgar_score_1min,
      apgar_score_5min,
      apgar_score_10min,
      resuscitation_done,
      place_of_delivery,
      delivery_assistant,
      counseling_on_infant_feeding ,
      counseling_on_exclusive_breastfeeding,
      counseling_on_infant_feeding_for_hiv_infected,
      mother_decision,
      placenta_complete,
      maternal_death_audited,
      cadre,
      other_delivery_complications,
      duration_of_labor,
      baby_sex,
      baby_condition,
      teo_given,
      birth_weight,
      bf_after_one_hour,
      birth_with_deformity,
      test_1_kit_name,
      test_1_kit_lot_no,
      test_1_kit_expiry,
      test_1_result,
      test_2_kit_name ,
      test_2_kit_lot_no,
      test_2_kit_expiry,
      test_2_result,
      final_test_result,
      patient_given_result,
      partner_hiv_tested,
      partner_hiv_status,
      prophylaxis_given,
      haart_given_at_anc,
      haart_given_at_delivery,
      haart_start_date,
      baby_azt_dispensed,
      baby_nvp_dispensed,
      clinical_notes
    )
      select
        e.patient_id,
        e.uuid,
        e.creator,
        e.visit_id,
        e.encounter_datetime,
        e.location_id,
        e.encounter_id,
        e.date_created,
        max(if(o.concept_id=1789,o.value_numeric,null)) as duration_of_pregnancy,
        max(if(o.concept_id=5630,o.value_coded,null)) as mode_of_delivery,
        max(if(o.concept_id=5599,o.value_datetime,null)) as date_of_delivery,
        max(if(o.concept_id=162092,o.value_coded,null)) as blood_loss,
        max(if(o.concept_id=162093,o.value_text,null)) as condition_of_mother,
        max(if(o.concept_id=159603,o.value_numeric,null)) as apgar_score_1min,
        max(if(o.concept_id=159604,o.value_numeric,null)) as apgar_score_5min,
        max(if(o.concept_id=159605,o.value_numeric,null)) as apgar_score_10min,
        max(if(o.concept_id=162131,o.value_coded,null)) as resuscitation_done,
        max(if(o.concept_id=1572,o.value_coded,null)) as place_of_delivery,
        max(if(o.concept_id=1573,o.value_coded,null)) as delivery_assistant,
        max(if(o.concept_id=1379 and o.value_coded=161651,o.value_coded,null)) as counseling_on_infant_feeding,
        max(if(o.concept_id=1379 and o.value_coded=161096,o.value_coded,null)) as counseling_on_exclusive_breastfeeding,
        max(if(o.concept_id=1379 and o.value_coded=162091,o.value_coded,null)) as counseling_on_infant_feeding_for_hiv_infected,
        max(if(o.concept_id=1151,o.value_coded,null)) as mother_decision,
        max(if(o.concept_id=163454,o.value_coded,null)) as placenta_complete,
        max(if(o.concept_id=163176,o.value_coded,null)) as maternal_death_audited,
        max(if(o.concept_id=1573,o.value_coded,null)) as cadre,
        max(if(o.concept_id=162093,o.value_text,null)) as other_delivery_complications,
        max(if(o.concept_id=159616,o.value_numeric,null)) as duration_of_labor,
        max(if(o.concept_id=1587,o.value_coded,null)) as baby_sex,
        max(if(o.concept_id=159917,o.value_coded,null)) as baby_condition,
        max(if(o.concept_id=1282 and o.value_coded = 84893,1,0)) as teo_given,
        max(if(o.concept_id=5916,o.value_numeric,null)) as birth_weight,
        max(if(o.concept_id=164819,o.value_coded,null)) as bf_after_one_hour,
        max(if(o.concept_id=164122,o.value_coded,null)) as birth_with_deformity,
        max(if(t.test_1_result is not null, t.kit_name, "")) as test_1_kit_name,
        max(if(t.test_1_result is not null, t.lot_no, "")) as test_1_kit_lot_no,
        max(if(t.test_1_result is not null, t.expiry_date, "")) as test_1_kit_expiry,
        max(if(t.test_1_result is not null, t.test_1_result, "")) as test_1_result,
        max(if(t.test_2_result is not null, t.kit_name, "")) as test_2_kit_name,
        max(if(t.test_2_result is not null, t.lot_no, "")) as test_2_kit_lot_no,
        max(if(t.test_2_result is not null, t.expiry_date, "")) as test_2_kit_expiry,
        max(if(t.test_2_result is not null, t.test_2_result, "")) as test_2_result,
        max(if(o.concept_id=159427,(case o.value_coded when 703 then "Positive" when 664 then "Negative" when 1138 then "Inconclusive" else "" end),null)) as final_test_result,
        max(if(o.concept_id=164848,(case o.value_coded when 1065 then "Yes" when 1066 then "No" else "" end),null)) as patient_given_result,
        max(if(o.concept_id=161557,(case o.value_coded when 1065 then "Yes" when 1066 then "No" else "" end),null)) as partner_hiv_tested,
        max(if(o.concept_id=1436,(case o.value_coded when 703 then "Positive" when 664 then "Negative" when 1067 then "Unknown" else "" end),null)) as partner_hiv_status,
        max(if(o.concept_id=1109,o.value_coded,null)) as prophylaxis_given,
        max(if(o.concept_id=5576,o.value_coded,null)) as haart_given_at_anc,
        max(if(o.concept_id=159595,o.value_coded,null)) as haart_given_at_delivery,
        max(if(o.concept_id=163784,date(o.value_datetime),null)) as haart_start_date,
        max(if(o.concept_id = 1282 and o.value_coded = 160123,1,0)) as baby_azt_dispensed,
        max(if(o.concept_id = 1282 and o.value_coded = 80586,1,0)) as baby_nvp_dispensed,
        max(if(o.concept_id=159395,o.value_text,null)) as clinical_notes

      from encounter e
        inner join obs o on e.encounter_id = o.encounter_id and o.voided =0
                            and o.concept_id in(1789,5630,5599,162092,162093,159603,159604,159605,162131,1572,1573,1379,1151,163454,163176,1573,162093,159616,1587,159917,1282,5916,164819,164122,159427,164848,161557,1436,1109,5576,159595,163784,159395)
        inner join
        (
          select encounter_type, uuid,name from form where
            uuid in('496c7cc3-0eea-4e84-a04c-2292949e2f7f')
        ) f on f.encounter_type=e.encounter_type
        inner join (
                     select
                       o.person_id,
                       o.encounter_id,
                       o.obs_group_id,
                       max(if(o.concept_id=1040, (case o.value_coded when 703 then "Positive" when 664 then "Negative" when 163611 then "Invalid"  else "" end),null)) as test_1_result ,
                       max(if(o.concept_id=1326, (case o.value_coded when 703 then "Positive" when 664 then "Negative" when 1175 then "N/A"  else "" end),null)) as test_2_result ,
                       max(if(o.concept_id=164962, (case o.value_coded when 164960 then "Determine" when 164961 then "First Response" else "" end),null)) as kit_name ,
                       max(if(o.concept_id=164964,o.value_text,null)) as lot_no,
                       max(if(o.concept_id=162502,date(o.value_datetime),null)) as expiry_date
                     from obs o
                       inner join encounter e on e.encounter_id = o.encounter_id
                       inner join form f on f.form_id=e.form_id and f.uuid in ('496c7cc3-0eea-4e84-a04c-2292949e2f7f')
                     where o.concept_id in (1040, 1326, 164962, 164964, 162502)
                     group by e.encounter_id, o.obs_group_id
                   ) t on e.encounter_id = t.encounter_id

      where e.date_created >= last_update_time
            or e.date_changed >= last_update_time
            or e.date_voided >= last_update_time
            or o.date_created >= last_update_time
            or o.date_voided >= last_update_time
      group by e.encounter_id
    ON DUPLICATE KEY UPDATE provider=VALUES(provider),visit_id=VALUES(visit_id),visit_date=VALUES(visit_date),encounter_id=VALUES(encounter_id),data_entry_date=VALUES(data_entry_date),duration_of_pregnancy=VALUES(duration_of_pregnancy),mode_of_delivery=VALUES(mode_of_delivery),date_of_delivery=VALUES(date_of_delivery),blood_loss=VALUES(blood_loss),condition_of_mother=VALUES(condition_of_mother),
      apgar_score_1min=VALUES(apgar_score_1min),apgar_score_5min=VALUES(apgar_score_5min),apgar_score_10min=VALUES(apgar_score_10min),resuscitation_done=VALUES(resuscitation_done),place_of_delivery=VALUES(place_of_delivery),delivery_assistant=VALUES(delivery_assistant),counseling_on_infant_feeding=VALUES(counseling_on_infant_feeding) ,counseling_on_exclusive_breastfeeding=VALUES(counseling_on_exclusive_breastfeeding),
      counseling_on_infant_feeding_for_hiv_infected=VALUES(counseling_on_infant_feeding_for_hiv_infected),mother_decision=VALUES(mother_decision),placenta_complete=VALUES(placenta_complete),maternal_death_audited=VALUES(maternal_death_audited),cadre=VALUES(cadre),other_delivery_complications=VALUES(other_delivery_complications),duration_of_labor=VALUES(duration_of_labor),baby_sex=VALUES(baby_sex),
      baby_condition=VALUES(baby_condition),teo_given=VALUES(teo_given),birth_weight=VALUES(birth_weight),bf_after_one_hour=VALUES(bf_after_one_hour),birth_with_deformity=VALUES(birth_with_deformity),test_1_kit_name=VALUES(test_1_kit_name),test_1_kit_lot_no=VALUES(test_1_kit_lot_no),test_1_kit_expiry=VALUES(test_1_kit_expiry),test_1_result=VALUES(test_1_result),test_2_kit_name =VALUES(test_2_kit_name),
      test_2_kit_lot_no=VALUES(test_2_kit_lot_no),test_2_kit_expiry=VALUES(test_2_kit_expiry),test_2_result=VALUES(test_2_result),final_test_result=VALUES(final_test_result),patient_given_result=VALUES(patient_given_result),partner_hiv_tested=VALUES(partner_hiv_tested),partner_hiv_status=VALUES(partner_hiv_status),prophylaxis_given=VALUES(prophylaxis_given),haart_given_at_anc=VALUES(haart_given_at_anc),
      haart_given_at_delivery=VALUES(haart_given_at_delivery),haart_start_date=VALUES(haart_start_date),baby_azt_dispensed=VALUES(baby_azt_dispensed),baby_nvp_dispensed=VALUES(baby_nvp_dispensed),clinical_notes=VALUES(clinical_notes)

    ;

  END;
