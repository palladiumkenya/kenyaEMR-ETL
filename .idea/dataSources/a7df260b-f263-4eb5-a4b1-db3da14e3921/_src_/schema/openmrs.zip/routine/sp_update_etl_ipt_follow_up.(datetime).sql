CREATE PROCEDURE sp_update_etl_ipt_follow_up(IN last_update_time DATETIME)
  BEGIN
    SELECT "Processing IPT followup forms", CONCAT("Time: ", NOW());
    insert into kenyaemr_etl.etl_ipt_follow_up(
      patient_id,
      uuid,
      provider,
      visit_id,
      visit_date,
      encounter_id,
      location_id,
      ipt_due_date,
      date_collected_ipt,
      hepatotoxity,
      peripheral_neuropathy,
      rash,
      adherence,
      outcome,
      discontinuation_reason,
      action_taken
    )
      select
        e.patient_id, e.uuid, e.creator, e.visit_id, e.encounter_datetime, e.encounter_id, e.location_id,
        max(if(o.concept_id = 164073, o.value_datetime, "" )) as ipt_due_date,
        max(if(o.concept_id = 164074, o.value_datetime, "" )) as date_collected_ipt,
        max(if(o.concept_id = 159098, (case o.value_coded when 1065 then "Yes" when 1066 then "No" else "" end), "" )) as hepatotoxity,
        max(if(o.concept_id = 118983, (case o.value_coded when 1065 then "Yes" when 1066 then "No" else "" end), "" )) as peripheral_neuropathy,
        max(if(o.concept_id = 512, (case o.value_coded when 1065 then "Yes" when 1066 then "No" else "" end), "" )) as rash,
        max(if(o.concept_id = 164075, (case o.value_coded when 159407 then "Poor" when 159405 then "Good" when 159406 then "Fair" when 164077 then "Very Good" when 164076 then "Excellent" when 1067 then "Unknown" else "" end), "" )) as adherence,
        max(if(o.concept_id = 160433, (case o.value_coded when 1267 then "Completed" when 5240 then "Lost to followup" when 159836 then "Discontinued" when 160034 then "Died" when 159492 then "Transferred Out" else "" end), "" )) as outcome,
        max(if(o.concept_id = 1266, (case o.value_coded when 102 then "Drug Toxicity" when 112141 then "TB" when 5622 then "Other" else "" end), "" )) as discontinuation_reason,
        max(if(o.concept_id = 160632, o.value_text, "" )) as action_taken
      from obs o
        inner join encounter e on e.encounter_id = o.encounter_id and e.voided =0
        inner join form f on f.form_id=e.form_id and f.uuid in ("22c68f86-bbf0-49ba-b2d1-23fa7ccf0259")
      where o.concept_id in (164073, 164074, 159098, 118983, 512, 164075, 160433, 1266, 160632)
            and e.date_created >= last_update_time
            or e.date_changed >= last_update_time
            or e.date_voided >= last_update_time
      group by e.encounter_id
    ON DUPLICATE KEY UPDATE visit_date=VALUES(visit_date),
      ipt_due_date=VALUES(ipt_due_date),
      date_collected_ipt=VALUES(date_collected_ipt),
      hepatotoxity=VALUES(hepatotoxity),
      peripheral_neuropathy=VALUES(peripheral_neuropathy),
      rash=VALUES(rash),
      adherence=VALUES(adherence),
      outcome=VALUES(outcome),
      discontinuation_reason=VALUES(discontinuation_reason),
      action_taken=VALUES(action_taken) ;

  END;
