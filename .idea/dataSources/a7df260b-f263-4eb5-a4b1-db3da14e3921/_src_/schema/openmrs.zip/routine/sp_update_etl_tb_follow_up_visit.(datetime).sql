CREATE PROCEDURE sp_update_etl_tb_follow_up_visit(IN last_update_time DATETIME)
  BEGIN



    insert into kenyaemr_etl.etl_tb_follow_up_visit(
      patient_id,
      uuid,
      provider,
      visit_id ,
      visit_date ,
      location_id,
      encounter_id,
      spatum_test,
      spatum_result,
      result_serial_number,
      quantity ,
      date_test_done,
      bacterial_colonie_growth,
      number_of_colonies,
      resistant_s,
      resistant_r,
      resistant_inh,
      resistant_e,
      sensitive_s,
      sensitive_r,
      sensitive_inh,
      sensitive_e,
      test_date,
      hiv_status,
      next_appointment_date
    )
      select
        e.patient_id,
        e.uuid,
        e.creator,
        e.visit_id,
        e.encounter_datetime,
        e.location_id,
        e.encounter_id,
        max(if(o.concept_id=159961,o.value_coded,null)) as spatum_test,
        max(if(o.concept_id=307,o.value_coded,null)) as spatum_result,
        max(if(o.concept_id=159968,o.value_numeric,null)) as result_serial_number,
        max(if(o.concept_id=160023,o.value_numeric,null)) as quantity,
        max(if(o.concept_id=159964,o.value_datetime,null)) as date_test_done,
        max(if(o.concept_id=159982,o.value_coded,null)) as bacterial_colonie_growth,
        max(if(o.concept_id=159952,o.value_numeric,null)) as number_of_colonies,
        max(if(o.concept_id=159956 and o.value_coded=84360,o.value_numeric,null)) as resistant_s,
        max(if(o.concept_id=159956 and o.value_coded=767,o.value_text,null)) as resistant_r,
        max(if(o.concept_id=159956 and o.value_coded=78280,o.value_coded,null)) as resistant_inh,
        max(if(o.concept_id=159956 and o.value_coded=75948,o.value_text,null)) as resistant_e,
        max(if(o.concept_id=159958 and o.value_coded=84360,o.value_text,null)) as sensitive_s,
        max(if(o.concept_id=159958 and o.value_coded=767,o.value_coded,null)) as sensitive_r,
        max(if(o.concept_id=159958 and o.value_coded=78280,o.value_coded,null)) as sensitive_inh,
        max(if(o.concept_id=159958 and o.value_coded=75948,o.value_coded,null)) as sensitive_e,
        max(if(o.concept_id=159964,o.value_datetime,null)) as test_date,
        max(if(o.concept_id=1169,o.value_coded,null)) as hiv_status,
        max(if(o.concept_id=5096,o.value_datetime,null)) as next_appointment_date
      from encounter e
        inner join obs o on e.encounter_id = o.encounter_id and o.voided =0
                            and o.concept_id in(159961,307,159968,160023,159964,159982,159952,159956,159958,159964,1169,5096)
        inner join
        (
          select encounter_type_id, uuid, name from encounter_type where
            uuid in('fbf0bfce-e9f4-45bb-935a-59195d8a0e35')
        ) et on et.encounter_type_id=e.encounter_type
      where e.date_created >= last_update_time
            or e.date_changed >= last_update_time
            or e.date_voided >= last_update_time
            or o.date_created >= last_update_time
            or o.date_voided >= last_update_time
      group by e.encounter_id
    ON DUPLICATE KEY UPDATE provider=VALUES(provider),visit_id=VALUES(visit_id),visit_date=VALUES(visit_date),encounter_id=VALUES(encounter_id),spatum_test=VALUES(spatum_test),spatum_result=VALUES(spatum_result),result_serial_number=VALUES(result_serial_number),quantity=VALUES(quantity) ,date_test_done=VALUES(date_test_done),bacterial_colonie_growth=VALUES(bacterial_colonie_growth),
      number_of_colonies=VALUES(number_of_colonies),resistant_s=VALUES(resistant_s),resistant_r=VALUES(resistant_r),resistant_inh=VALUES(resistant_inh),resistant_e=VALUES(resistant_e),sensitive_s=VALUES(sensitive_s),sensitive_r=VALUES(sensitive_r),sensitive_inh=VALUES(sensitive_inh),sensitive_e=VALUES(sensitive_e),test_date=VALUES(test_date),hiv_status=VALUES(hiv_status),next_appointment_date=VALUES(next_appointment_date)
    ;

  END;
